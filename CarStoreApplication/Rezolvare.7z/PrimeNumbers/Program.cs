﻿using System;

namespace PrimeNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please write your number:");
            int n = int.Parse(Console.ReadLine());
            int d = 3;


            //   Console.WriteLine("FIND PRIME NUMBERS");
            //int n = 50;
            printPrime(n);
            //printNumbers(n,d);
     
            

        }

        //to check if digit 3 is present



        // function check whether  
        // a number is prime or not 
        static bool isPrime(int n)
        {

            // Corner case 
            if (n <= 1)
                return false;

            // Check from 2 to n-1 
            for (int i = 2; i < n; i++)
                if (n % i == 0)
                    return false;

            return true;
        }





        // Function to print primes 
        static void printPrime(int n)
        {
            for (int i = 2; i <= n; i++)
            {
                if (isPrime(i) )
                    Console.Write(i + " \r\n");
            }
        }



        // Returns true if d is present as digit 
        // in number x. 
        static bool isDigitPresent(int x, int d)
        {

            // Breal loop if d is present as digit 
            while (x > 0)
            {
                if (x % 10 == d)
                    break;

                x = x / 10;
            }

            // If loop broke 
            return (x > 0);
        }

        static void printNumbers(int n, int d)
        {

            // Check all numbers one by one 
            for (int i = 2; i <= n; i++)

                // checking for digit 
                if (i == d || isDigitPresent(i, d) && isPrime(i))
                    Console.Write(i + " ");
        }


    }
}
